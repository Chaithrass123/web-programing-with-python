from django.db import models
from user_management.models import User

class Course(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20, unique=True)
    description = models.TextField()
    
    def _str_(self):
        return f"{self.code} - {self.name}"

class Subject(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='subjects')
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20, unique=True)
    credits = models.IntegerField()
    faculty = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    
    def _str_(self):
        return f"{self.code} - {self.name}"