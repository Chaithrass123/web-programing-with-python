from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import Course, Subject
from user_management.views import is_faculty

@login_required
def course_list(request):
    courses = Course.objects.all()
    return render(request, 'course_management/course_list.html', {
        'courses': courses
    })

@login_required
@user_passes_test(is_faculty)
def my_courses(request):
    subjects = Subject.objects.filter(faculty=request.user)
    return render(request, 'course_management/my_courses.html', {
        'subjects': subjects
    })