from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Leave

@login_required
def leave_request(request):
    if request.method == 'POST':
        leave = Leave.objects.create(
            faculty=request.user,
            leave_type=request.POST.get('leave_type'),
            start_date=request.POST.get('start_date'),
            end_date=request.POST.get('end_date'),
            reason=request.POST.get('reason'),
            status='pending'
        )
        messages.success(request, 'Leave request submitted successfully')
        return redirect('leave_management:my_leaves')
    return render(request, 'leave_management/leave_request.html')

@login_required
def my_leaves(request):
    leaves = Leave.objects.filter(faculty=request.user)
    return render(request, 'leave_management/my_leaves.html', {'leaves': leaves})

@login_required
def approve_leave(request, leave_id):
    leave = Leave.objects.get(id=leave_id)
    if request.method == 'POST':
        action = request.POST.get('action')
        leave.status = 'approved' if action == 'approve' else 'rejected'
        leave.save()
        messages.success(request, f'Leave request {leave.status} successfully')
    return redirect('user_management:admin_dashboard')