from django.contrib import admin
from .models import Leave

class LeaveAdmin(admin.ModelAdmin):
    list_display = ('faculty', 'leave_type', 'start_date', 'end_date', 'status')
    list_filter = ('leave_type', 'status')
    search_fields = ('faculty__username', 'reason')

admin.site.register(Leave, LeaveAdmin)


