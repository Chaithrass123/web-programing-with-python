from django.urls import path
from . import views

app_name = 'leave_management'

urlpatterns = [
    path('request/', views.leave_request, name='leave_request'),
    path('my-leaves/', views.my_leaves, name='my_leaves'),
    path('approve/<int:leave_id>/', views.approve_leave, name='approve_leave'),
]