from django.contrib import admin
from .models import FacultyProfile

class FacultyProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'department', 'designation', 'experience')
    search_fields = ('user__username', 'department', 'designation')
    list_filter = ('department', 'designation')

admin.site.register(FacultyProfile, FacultyProfileAdmin)