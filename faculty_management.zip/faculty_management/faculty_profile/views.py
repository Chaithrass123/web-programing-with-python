from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import FacultyProfile

@login_required
def profile_view(request):
    try:
        profile = FacultyProfile.objects.get(user=request.user)
    except FacultyProfile.DoesNotExist:
        profile = None
    return render(request, 'faculty_profile/profile.html', {'profile': profile})

@login_required
def profile_edit(request):
    profile = FacultyProfile.objects.get(user=request.user)
    if request.method == 'POST':
        profile.department = request.POST.get('department')
        profile.designation = request.POST.get('designation')
        profile.qualification = request.POST.get('qualification')
        profile.experience = request.POST.get('experience')
        profile.save()
        return redirect('profile_view')
    return render(request, 'faculty_profile/profile_edit.html', {'profile': profile})