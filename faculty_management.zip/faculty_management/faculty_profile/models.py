from django.db import models
from user_management.models import User

class FacultyProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    department = models.CharField(max_length=100)
    designation = models.CharField(max_length=100)
    qualification = models.CharField(max_length=200)
    experience = models.IntegerField()
    date_of_joining = models.DateField()
    
    def _str_(self):
        return f"{self.user.username} - {self.department}"
