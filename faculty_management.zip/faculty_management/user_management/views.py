from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from .models import User
from leave_management.models import Leave

def is_admin(user):
    return user.user_type == 'admin'

def is_faculty(user):
    return user.user_type == 'faculty'

def admin_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user and user.user_type == 'admin':
            login(request, user)
            return redirect('admin_dashboard')
        messages.error(request, 'Invalid admin credentials')
    return render(request, 'user_management/admin_login.html')

def faculty_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None and user.user_type == 'faculty':
            login(request, user)
            return redirect('/faculty-dashboard/')  # Use direct URL path instead of name
        messages.error(request, 'Invalid faculty credentials')
    return render(request, 'user_management/faculty_login.html')



@login_required
@user_passes_test(is_admin)
def admin_dashboard(request):
    leaves = Leave.objects.all().order_by('-created_at')
    return render(request, 'user_management/admin_dashboard.html', {
        'leaves': leaves
    })


@login_required
@user_passes_test(is_faculty)
def faculty_dashboard(request):
    return render(request, 'user_management/faculty_dashboard.html')

def logout_view(request):
    logout(request)
    return redirect('choose_login')

def choose_login(request):
    print("Choose login view is being called!")
    return render(request, 'user_management/choose_login.html')

def faculty_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None and user.user_type == 'faculty':
            login(request, user)
            return redirect('user_management:faculty_dashboard')  # Make sure this matches URL name
        messages.error(request, 'Invalid faculty credentials')
    return render(request, 'user_management/faculty_login.html')

